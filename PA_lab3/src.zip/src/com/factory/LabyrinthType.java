package com.factory;

/**
 * Created by alber_000 on 3/6/2016.
 */
public enum LabyrinthType {
    MATRIX,LIST
}
